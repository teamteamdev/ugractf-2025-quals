package com.rozetkin.secusafe.ui.info

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class InfoViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "This is Info and settings page, but there's nothing here. So you can go back to the main page XD"
    }
    val text: LiveData<String> = _text
}