package com.rozetkin.secusafe

import android.Manifest
import android.app.ActivityManager
import android.app.ApplicationStartInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.view.ViewTreeObserver
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.bottomnavigation.BottomNavigationView
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.rozetkin.secusafe.databinding.ActivityMainBinding
import java.util.concurrent.Executors
import kotlin.system.exitProcess
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    public var isChangeLogAccepted = false
    companion object {
        private const val NOTIFICATION_PERMISSION_REQUEST_CODE = 101
    }

    // Handler for posting to the main thread
    private val mainThreadHandler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Check for notification permission on Android 13+
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                NOTIFICATION_PERMISSION_REQUEST_CODE
            )
        }

        val navView: BottomNavigationView = binding.navView
        val navController = findNavController(R.id.nav_host_fragment_activity_main)
        // Passing each menu ID as a set of Ids because each menu should be considered as top-level destinations.
        val appBarConfiguration = AppBarConfiguration(
            setOf(
                R.id.navigation_encrypt, R.id.navigation_dashboard, R.id.navigation_info
            )
        )

        setupActionBarWithNavController(navController, appBarConfiguration)
        navView.setupWithNavController(navController)

        // Add a global layout listener to execute code after the layout has been drawn
        binding.root.viewTreeObserver.addOnGlobalLayoutListener(
            object : ViewTreeObserver.OnGlobalLayoutListener {
                override fun onGlobalLayout() {
                    binding.root.viewTreeObserver.removeOnGlobalLayoutListener(this)

                    // Execute the startup info collection in a separate thread
                    Executors.newSingleThreadExecutor().execute {
                        // Get the ActivityManager
                        val activityManager = getSystemService(ACTIVITY_SERVICE) as ActivityManager

                        var startInfos: List<ApplicationStartInfo>
                        var startInfo: ApplicationStartInfo

                        do {
                            startInfos = activityManager.getHistoricalProcessStartReasons(5)
                            startInfo = startInfos[0] // Get the first entry
                            Log.i("ApplicationStartInfo", "Startup State: ${startInfo.startupState}")
                        } while (startInfo.startupState == 0)

                        if (startInfo.startupState == ApplicationStartInfo.STARTUP_STATE_FIRST_FRAME_DRAWN) {
                            // Process relevant information
                            val reason = startInfo.reason // Why the app started
                            val startType = startInfo.startType // Cold, warm, or hot start
                            val launchTimeMillis = startInfo.getStartupTimestamps()[ApplicationStartInfo.START_TIMESTAMP_LAUNCH]
                                ?.div(1_000_000) // Launch time in milliseconds
                            val forkTimeMillis = startInfo.getStartupTimestamps()[ApplicationStartInfo.START_TIMESTAMP_FORK]
                                ?.div(1_000_000) // Process fork time in milliseconds
                            val appCreateTimeMillis = startInfo.getStartupTimestamps()[ApplicationStartInfo.START_TIMESTAMP_APPLICATION_ONCREATE]
                                ?.div(1_000_000) // Application onCreate() time in milliseconds
                            val appBindTimeMillis = startInfo.getStartupTimestamps()[ApplicationStartInfo.START_TIMESTAMP_BIND_APPLICATION]
                                ?.div(1_000_000) // Application Bind time in milliseconds
                            val appFirstFrameTimeMillis = startInfo.getStartupTimestamps()[ApplicationStartInfo.START_TIMESTAMP_FIRST_FRAME]
                                ?.div(1_000_000) // First frame drawn time in milliseconds
                            val appFullyDrawnTimeMillis = startInfo.getStartupTimestamps()[ApplicationStartInfo.START_TIMESTAMP_FULLY_DRAWN]
                                ?.div(1_000_000) // Fully drawn time in milliseconds

                            Log.i("ApplicationStartInfo", "Start Reason: ${reasonToString(reason)}")
                            Log.i("ApplicationStartInfo", "Start Type: ${startTypeToString(startType)}")
                        }

                        // Move show_changelog() to the main thread using the handler
                        mainThreadHandler.post {
                            show_changelog(binding.root)
                        }
                    }
                }
            }
        )
    }

    fun reasonToString(reason: Int): String {
        return when (reason) {
            ApplicationStartInfo.START_REASON_ALARM -> "ALARM"
            ApplicationStartInfo.START_REASON_BACKUP -> "BACKUP"
            ApplicationStartInfo.START_REASON_BOOT_COMPLETE -> "BOOT_COMPLETE"
            ApplicationStartInfo.START_REASON_BROADCAST -> "BROADCAST"
            ApplicationStartInfo.START_REASON_CONTENT_PROVIDER -> "CONTENT_PROVIDER"
            ApplicationStartInfo.START_REASON_JOB -> "JOB"
            ApplicationStartInfo.START_REASON_LAUNCHER -> "LAUNCHER"
            ApplicationStartInfo.START_REASON_LAUNCHER_RECENTS -> "LAUNCHER_RECENTS"
            ApplicationStartInfo.START_REASON_OTHER -> "OTHER"
            ApplicationStartInfo.START_REASON_PUSH -> "PUSH"
            ApplicationStartInfo.START_REASON_SERVICE -> "SERVICE"
            ApplicationStartInfo.START_REASON_START_ACTIVITY -> "START_ACTIVITY"
            else -> "UNKNOWN" // Handle any unexpected reason codes
        }
    }

    fun startTypeToString(startType: Int): String {
        return when (startType) {
            ApplicationStartInfo.START_TYPE_UNSET -> "UNSET"
            ApplicationStartInfo.START_TYPE_COLD -> "COLD"
            ApplicationStartInfo.START_TYPE_WARM -> "WARM"
            ApplicationStartInfo.START_TYPE_HOT -> "HOT"
            else -> "UNKNOWN" // Handle any unexpected start types
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == NOTIFICATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Notification permission granted; you can proceed with notifications.
            } else {
                exitProcess(0)
            }
        }
    }

    fun show_changelog(view: View) {
        val changelog = """
            Version 1.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.1
            - Added support for Android 16 beta
            - Fixed a bug where the app would crash on startup
            - Improved performance and stability
            - Added new features and enhancements
            - Updated the UI and fixed minor issues
            - Added support for new devices and screen sizes
            - Changed some cryptographic algorithms
            - If you read this, you are awesome nya~
            - Implemented time travel to allow debugging in the past
            - Replaced all error messages with motivational quotes from Shakespeare (not really)
            - Introduced a quantum random number generator for unpredictable results (and unintroduced it)
            - Patched a bug that caused unicorns to crash the system
            - Enhanced performance by convincing electrons to move faster
            - Added inter-dimensional notifications for alternate universe updates
            - Upgraded the app to run on Martian rovers and deep-sea submarines
            - Developed an AI that writes code in its spare time (and tells jokes)
            - Optimized memory by storing data in a mini black hole (use with caution)
            - Fixed a critical issue where widgets only opened when serenaded with the right tune
            - Enabled cosmic ray resistance to protect against intergalactic interference
            - Now supports teleportation mode—ideal for developers on the go
            - If you found this changelog, you’re now officially a certified wizard of absurdity!
            - ...and many more mind-bending improvements that defy the laws of physics!
        """.trimIndent()
        // show as a popup
        val dialog = androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Changelog")
            .setMessage(changelog)
            .setPositiveButton("OK") { dialog, _ ->
                run {
                    dialog.dismiss()
                    isChangeLogAccepted = true
                }
            }
            .create()
        dialog.show()
    }
}