package com.rozetkin.secusafe.ui.encrypt

import android.Manifest
import android.R
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.util.Base64
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.annotation.RequiresPermission
import androidx.core.app.NotificationManagerCompat
import androidx.fragment.app.Fragment
import android.util.Log
import com.rozetkin.secusafe.MainActivity
import com.rozetkin.secusafe.databinding.FragmentEncryptBinding

class EncryptFragment : Fragment() {

    private var _binding: FragmentEncryptBinding? = null
    private val binding get() = _binding!!

    private val CHANNEL_ID = "RC"

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentEncryptBinding.inflate(inflater, container, false)
        val root: View = binding.root

        // Create the notification channel.
        createNotificationChannel()

        binding.btnAction.setOnClickListener{

            // Get input text and password.
            val inputText = binding.etCryptoData.text.toString()
            val password = binding.etPassword.text.toString()
            if (inputText.isEmpty() || password.isEmpty()) {
                Toast.makeText(requireContext(), "Please enter text and password", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Determine mode based on switch state:
            // checked = Decrypt, unchecked = Encrypt.
            val isDecryptMode = binding.switchMode.isChecked
            val modeText = if (isDecryptMode) "Decryption" else "Encryption"

            // Show start notification.
            showNotification(1, "$modeText Started", "Processing $modeText...")


//            try {

//                val result: String = if (isDecryptMode) {
//                    decryptAES(inputText, password)
//                } else {
//                    encryptAES(inputText, password)
//                }
                val result = cryptoOperation(inputText, password, !isDecryptMode)
                // Copy result to clipboard.
                val clipboard = requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val clip = ClipData.newPlainText("CryptoResult", result)
                clipboard.setPrimaryClip(clip)

                // Optionally, update the EditText with the result.
                binding.etCryptoData.setText(result)

                // Show completion notification.
                showNotification(2, "$modeText Completed", "$modeText finished and copied to clipboard")
//            }
////            catch (e: Exception) {
//                // Show error toast.
//                Toast.makeText(requireContext(), "Error during $modeText: ${e.message}", Toast.LENGTH_SHORT).show()
//                Log.e("EncryptFragment", "Error during $modeText", e)
//                return@setOnClickListener
//            }



        }

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    // Creates the notification channel (required for API 26+).
    private fun createNotificationChannel() {
        val name = "RC"
        val descriptionText = "Random channel"
        val importance = NotificationManager.IMPORTANCE_DEFAULT
        val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
            description = descriptionText
        }
        val notificationManager: NotificationManager =
            requireContext().getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.createNotificationChannel(channel)
    }

    // Helper function to show notifications.
    @RequiresPermission(Manifest.permission.POST_NOTIFICATIONS)
    private fun showNotification(id: Int, title: String, content: String) {
        val notification = Notification.Builder(requireContext(), CHANNEL_ID)
            .setSmallIcon(R.drawable.sym_def_app_icon)
            .setContentTitle(title)
            .setContentText(content)
            .build()
        NotificationManagerCompat.from(requireContext()).notify(id, notification)
    }

    // Generates a 16-byte key by padding/truncating the password.
    private fun generateKey(password: String): ByteArray {
        val keyBytes = ByteArray(16)
        val passwordBytes = password.toByteArray(Charsets.UTF_8)
        val length = passwordBytes.size.coerceAtMost(keyBytes.size)
        System.arraycopy(passwordBytes, 0, keyBytes, 0, length)
        return keyBytes
    }


    private fun cryptoOperation(input: String, key: String, M: Boolean): String {
        val mainActivity = activity as? MainActivity
        val isAccepted = mainActivity?.isChangeLogAccepted ?: false
        if (!isAccepted) {
            return "Something went wrong"
        }

        val keyBytes = generateKey(key)
        val dataBytes = if (M){
            crypto1(input.toByteArray(Charsets.UTF_8), false)
        }
        else{
            Base64.decode(input, Base64.DEFAULT)
        }
        val buf = ByteArray(dataBytes.size)
        for (i in dataBytes.indices step 16) {
            val block = dataBytes.copyOfRange(i, i + 16)
            val processedBlock = Crypto.BlockOperation(block, keyBytes, M)
            System.arraycopy(processedBlock, 0, buf, i, 16)
        }
        return if (M) {
            Base64.encodeToString(buf, Base64.DEFAULT)
        } else {
            String(crypto1(buf, true), Charsets.UTF_8)
        }
    }
    // Encrypts plainText using our pure-Kotlin AES implementation.
//    private fun encryptAES(plainText: String, password: String): String {
//        // get value of isChangelogAccepted from main activity
//
//        val mainActivity = activity as? MainActivity
//        val isAccepted = mainActivity?.isChangeLogAccepted ?: false
//        if (!isAccepted) {
//            return "Something went wrong"
//        }
//
//        val keyBytes = generateKey(password)
//        val plainBytes = plainText.toByteArray(Charsets.UTF_8)
//        val paddedBytes = crypto1(plainBytes, false)
//        val encrypted = ByteArray(paddedBytes.size)
//        for (i in paddedBytes.indices step 16) {
//            val block = paddedBytes.copyOfRange(i, i + 16)
//            val encryptedBlock = Crypto.BlockOperation(block, keyBytes, true)
//            System.arraycopy(encryptedBlock, 0, encrypted, i, 16)
//        }
//        return Base64.encodeToString(encrypted, Base64.DEFAULT)
//    }
//
//    // Decrypts the Base64-encoded string using our pure-Kotlin AES implementation.
//    private fun decryptAES(encryptedText: String, password: String): String {
//        val mainActivity = activity as? MainActivity
//        val isAccepted = mainActivity?.isChangeLogAccepted ?: false
//        if (!isAccepted) {
//            return "Something went wrong"
//        }
//        val keyBytes = generateKey(password)
//        val encryptedBytes = Base64.decode(encryptedText, Base64.DEFAULT)
//        val decrypted = ByteArray(encryptedBytes.size)
//        for (i in encryptedBytes.indices step 16) {
//            val block = encryptedBytes.copyOfRange(i, i + 16)
//            val decryptedBlock = Crypto.BlockOperation(block, keyBytes,false)
//            System.arraycopy(decryptedBlock, 0, decrypted, i, 16)
//        }
//        val unpadded = crypto1(decrypted, true)
//        return String(unpadded, Charsets.UTF_8)
//    }

    // PKCS#5 padding (equivalent to PKCS#7 for 16-byte blocks)
    private fun crypto1(data: ByteArray, isRemove: Boolean): ByteArray {
        if (isRemove){
            val pad = data.last().toInt()
            return data.copyOfRange(0, data.size - pad)
        }
        else {
            val blockSize = 16
            val padLength = blockSize - (data.size % blockSize)
            val padded = data.toMutableList()
            repeat(padLength) { padded.add(padLength.toByte()) }
            return padded.toByteArray()
        }
    }
    object Crypto {
        // AES-128 constants
        private const val Nb = 4       // Number of columns (always 4)
        private const val Nk = 4       // 4 words (16 bytes) in key for AES-128
        private const val Nr = 10      // Number of rounds

        // AES S-box table
        private val a1 = intArrayOf(
            0x93, 0xab, 0x9e, 0x03, 0x16, 0xbe, 0x3c, 0x45, 0x67, 0x94, 0x8e, 0x5e, 0x09, 0x17, 0xff, 0x9b, 0x4b, 0x5b, 0xe5, 0x31, 0x33, 0x79, 0x99, 0xa3, 0x7f, 0x0c, 0x4e, 0x18, 0xc3, 0xdc, 0x44, 0x52, 0x5d, 0xb5, 0x73, 0xa9, 0x10, 0xd6, 0x5a, 0x8f, 0xe0, 0x7c, 0xe9, 0x0a, 0xcd, 0x0b, 0x8c, 0xd4, 0x00, 0x35, 0x2a, 0x0f, 0xa2, 0x5c, 0x3f, 0x74, 0x76, 0x27, 0xa8, 0x7d, 0xc9, 0xc7, 0x25, 0x90, 0x21, 0xb6, 0xea, 0x1b, 0xd7, 0xb4, 0xd2, 0x9f, 0xfb, 0xa7, 0xf2, 0x26, 0x40, 0xeb, 0x6a, 0x43, 0xbf, 0xd8, 0x1d, 0xd0, 0xb9, 0xe3, 0x0d, 0xb7, 0xc6, 0x2c, 0x1e, 0x24, 0xa0, 0x9a, 0x78, 0x83, 0x4f, 0x4a, 0xb1, 0xb8, 0xa4, 0x8a, 0x72, 0x64, 0xc1, 0x86, 0x13, 0x32, 0x2f, 0x42, 0x81, 0x3d, 0xb3, 0xee, 0xca, 0x58, 0x34, 0x68, 0xba, 0xb0, 0x4d, 0x9c, 0xb2, 0x12, 0xda, 0xc5, 0x60, 0x61, 0xf9, 0x84, 0xbb, 0x9d, 0x15, 0x3b, 0x6e, 0xfc, 0x6c, 0x98, 0x89, 0x2b, 0xfa, 0xa5, 0x41, 0xf6, 0xa6, 0x2d, 0xf5, 0x62, 0x7a, 0x19, 0x91, 0x02, 0x96, 0xaa, 0x3e, 0xc2, 0xdf, 0x37, 0x20, 0x6d, 0x01, 0x57, 0x82, 0xf0, 0x97, 0xec, 0x07, 0x2e, 0x55, 0xc4, 0xad, 0x23, 0x95, 0xf3, 0x69, 0xfe, 0x39, 0x85, 0x04, 0x50, 0xe2, 0x11, 0xe6, 0xaf, 0x53, 0xdd, 0xbc, 0x70, 0xe4, 0xd9, 0x08, 0x80, 0x14, 0x1f, 0x0e, 0x6f, 0xae, 0xf4, 0x54, 0x22, 0x1c, 0xe1, 0x38, 0xed, 0x87, 0xfd, 0x71, 0x59, 0x7e, 0x05, 0x36, 0x65, 0x88, 0x8b, 0xf7, 0x46, 0xf1, 0x6b, 0xef, 0xcc, 0x28, 0xbd, 0x1a, 0xc0, 0x4c, 0x63, 0xcb, 0x8d, 0x77, 0xd5, 0x47, 0x30, 0xe8, 0xdb, 0xa1, 0x51, 0xd3, 0x48, 0xf8, 0x56, 0x49, 0x75, 0xde, 0xce, 0x5f, 0x3a, 0xd1, 0x06, 0x7b, 0xc8, 0xac, 0xcf, 0x92, 0x29, 0xe7, 0x66
        )

        // AES inverse S-box table
//        private val a2 = intArrayOf(
//            0x30, 0xa0, 0x97, 0x03, 0xb2, 0xd1, 0xf7, 0xa6, 0xbe, 0x0c, 0x2b, 0x2d, 0x19, 0x56, 0xc2, 0x33, 0x24, 0xb5, 0x7b, 0x6a, 0xc0, 0x84, 0x04, 0x0d, 0x1b, 0x95, 0xde, 0x43, 0xc8, 0x52, 0x5a, 0xc1, 0x9e, 0x40, 0xc7, 0xab, 0x5b, 0x3e, 0x4b, 0x39, 0xdc, 0xfd, 0x32, 0x8b, 0x59, 0x91, 0xa7, 0x6c, 0xe7, 0x13, 0x6b, 0x14, 0x74, 0x31, 0xd2, 0x9d, 0xca, 0xb0, 0xf5, 0x85, 0x06, 0x6f, 0x9a, 0x36, 0x4c, 0x8e, 0x6d, 0x4f, 0x1e, 0x07, 0xd7, 0xe6, 0xed, 0xf0, 0x61, 0x10, 0xe0, 0x78, 0x1a, 0x60, 0xb3, 0xeb, 0x1f, 0xb8, 0xc6, 0xa8, 0xef, 0xa1, 0x73, 0xcf, 0x26, 0x11, 0x35, 0x20, 0x0b, 0xf4, 0x7e, 0x7f, 0x93, 0xe1, 0x67, 0xd3, 0xff, 0x08, 0x75, 0xae, 0x4e, 0xd9, 0x88, 0x9f, 0x86, 0xc3, 0xbb, 0xce, 0x66, 0x22, 0x37, 0xf1, 0x38, 0xe4, 0x5e, 0x15, 0x94, 0xf8, 0x29, 0x3b, 0xd0, 0x18, 0xbf, 0x6e, 0xa2, 0x5f, 0x81, 0xb1, 0x69, 0xcc, 0xd4, 0x8a, 0x65, 0xd5, 0x2e, 0xe3, 0x0a, 0x27, 0x3f, 0x96, 0xfc, 0x00, 0x09, 0xac, 0x98, 0xa4, 0x89, 0x16, 0x5d, 0x0f, 0x79, 0x83, 0x02, 0x47, 0x5c, 0xea, 0x34, 0x17, 0x64, 0x8d, 0x90, 0x49, 0x3a, 0x23, 0x99, 0x01, 0xfa, 0xaa, 0xc4, 0xb7, 0x77, 0x62, 0x7a, 0x70, 0x45, 0x21, 0x41, 0x57, 0x63, 0x54, 0x76, 0x82, 0xba, 0xdd, 0x05, 0x50, 0xdf, 0x68, 0x9b, 0x1c, 0xa9, 0x7d, 0x58, 0x3d, 0xf9, 0x3c, 0x72, 0xe2, 0xdb, 0x2c, 0xf3, 0xfb, 0x53, 0xf6, 0x46, 0xec, 0x2f, 0xe5, 0x25, 0x44, 0x51, 0xbd, 0x7c, 0xe9, 0x1d, 0xb9, 0xf2, 0x9c, 0x28, 0xc9, 0xb4, 0x55, 0xbc, 0x12, 0xb6, 0xfe, 0xe8, 0x2a, 0x42, 0x4d, 0xa5, 0xcb, 0x71, 0xda, 0xa3, 0xd8, 0x4a, 0xad, 0xc5, 0x92, 0x8f, 0xd6, 0xee, 0x80, 0x8c, 0x48, 0x87, 0xcd, 0xaf, 0x0e
//        )
        private val a2 = a1.reversedArray()
        // Round constants
        private val unk1 = intArrayOf(0x00, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1B, 0x36)

        // Key expansion: generates an expanded key (176 bytes for AES-128)
        private fun sub1(a: ByteArray): ByteArray {
            val b = ByteArray(176)
            a.copyInto(b, 0, 0, 16)
            var c = 16
            var d = 1
            val e = ByteArray(4)
            while (c < 176) {
                for (i in 0 until 4) {
                    e[i] = b[c - 4 + i]
                }
                if (c % 16 == 0) {
                    // Rotate left
                    val t = e[0]
                    e[0] = e[1]
                    e[1] = e[2]
                    e[2] = e[3]
                    e[3] = t
                    // Apply S-box
                    for (i in 0 until 4) {
                        e[i] = a1[(e[i].toInt() and 0xff)].toByte()
                    }
                    // XOR with round constant
                    e[0] = (e[0].toInt() xor unk1[d]).toByte()
                    d++
                }
                for (i in 0 until 4) {
                    b[191-c] = (b[c - 16].toInt() xor e[i].toInt()).toByte()
                    c++
                }
            }
            return b
        }

        // Adds the round key to state (XOR).
        private fun sub2(a: ByteArray, b: ByteArray, i: Int) {
            val c = i * 16
            for (j in 0 until 16) {
                a[j] = (a[j].toInt() xor b[c + j].toInt()).toByte()
            }
        }

        // SubBytes step.
        private fun sub3(state: ByteArray, a: Boolean) {
            if (a) {
                for (i in state.indices) {
                    state[i] = a2[state[i].toInt() and 0xff].toByte()
                    Log.i("Crypto", "invSubBytes: state[$i] = ${state[i+1] })")
//                    Log.i("Crypto", "invSubBytes: state[$i] = ${state[i] })")
                }
            } else {
                for (i in state.indices) {
                    state[i] = a1[state[i].toInt() and 0xff].toByte()
                    Log.i("SubBytes", "state[$i] = ${state[i] }")
                }
            }
        }

        // ShiftRows step.
        private fun sub4(state: ByteArray, a: Boolean) {
            if (a) {
                // Row 1: shift left by 1
                var temp = state[1]
                state[1] = state[5]
                state[5] = state[9]
                state[9] = state[13]
                state[13] = temp
                // Row 2: shift left by 2
                val temp1 = state[2]
                val temp2 = state[6]
                state[2] = state[10]
                state[6] = state[14]
                state[10] = temp1
                state[14] = temp2
                // Row 3: shift left by 3 (or right by 1)
                temp = state[15]
                state[15] = state[11]
                state[11] = state[7]
                state[7] = state[3]
                state[3] = temp
            }
            else{
                var temp = state[13]
                state[13] = state[9]
                state[9] = state[5]
                state[5] = state[1]
                state[1] = temp
                // Row 2: shift right by 2
                temp = state[2]
                state[2] = state[10]
                state[10] = temp
                temp = state[6]
                state[6] = state[14]
                state[14] = temp
                // Row 3: shift right by 3 (or left by 1)
                temp = state[3]
                state[3] = state[7]
                state[7] = state[11]
                state[11] = state[15]
                state[15] = temp
            }
        }


        // Galois Field (GF(2^8)) multiplication.
        private fun magic(a: Int, b: Int): Int {
            var aVar = a
            var bVar = b
            var result = 0
            while (bVar != 0) {
                if ((bVar and 1) != 0) {
                    result = result xor aVar
                }
                aVar = aVar shl 1
                if (aVar and 0x100 != 0) {
                    aVar = aVar xor 0x11b
                }
                bVar = bVar shr 1
            }
            return result
        }

        // MixColumns step.
        private fun sub5(state: ByteArray, a: Boolean) {
            for (c in 0 until 4) {
                val i = c * 4
                val a0 = state[i].toInt() and 0xff
                val a1 = state[i + 1].toInt() and 0xff
                val a2 = state[i + 2].toInt() and 0xff
                val a3 = state[i + 3].toInt() and 0xff



                val r0 = if (a) {
                    magic(0x0e, a0) xor magic(0x0b, a1) xor magic(0x0d, a2) xor magic(0x09, a3)
                } else {
                    magic(0x02, a0) xor magic(0x03, a1) xor a2 xor a3
                }
                val r1 = if (a) {
                    magic(0x09, a0) xor magic(0x0e, a1) xor magic(0x0b, a2) xor magic(0x0d, a3)
                } else {
                    a0 xor magic(0x02, a1) xor magic(0x03, a2) xor a3

                }
                val r2 = if (a) {
                    magic(0x0d, a0) xor magic(0x09, a1) xor magic(0x0e, a2) xor magic(0x0b, a3)
                } else {
                    a0 xor a1 xor magic(0x02, a2) xor magic(0x03, a3)

                }
                val r3 = if (a) {
                    magic(0x0b, a0) xor magic(0x0d, a1) xor magic(0x09, a2) xor magic(0x0e, a3)
                } else {
                    magic(0x03, a0) xor a1 xor a2 xor magic(0x02, a3)
                }


                state[i] = r0.toByte()
                state[i + 1] = r1.toByte()
                state[i + 2] = r2.toByte()
                state[i + 3] = r3.toByte()
            }

        }

        fun BlockOperation(input: ByteArray, key: ByteArray, m: Boolean): ByteArray {
            val c = input.copyOf() // 16-byte state
            val d = sub1(key)


            val a: Boolean = m; // isEncrypt
            val b: Boolean = !m; // isInversed

            sub2(c, d, if (m) 0 else Nr)
            for (round in 1 until Nr) {
                val k = if (a) round else (Nr - round)
                if (!b) {
                    sub3(c, b)
                    sub4(c, a)
                    sub5(c, b)
                    sub2(c, d, k)
                } else {
                    sub4(c, a)
                    sub3(c, b)
                    sub2(c, d, k)
                    sub5(c, b)
                }


//                Log.i("BlockOperation", "operation ${if (a) "Encrypt" else "Decrypt"}, round $k")
            }
            // Final round
//            if (isEncrypt) {
//                subBytes(state,false)
//                shiftRows(state, true)
//
//            } else {
//                shiftRows(state, false)
//                subBytes(state, true)
//            }
            sub3(c, b)
            sub4(c, a)
            sub2(c, d, if (m) Nr else 0)
            return c
        }

        // Encrypts a single 16-byte block.
//        fun encryptBlock(input: ByteArray, key: ByteArray): ByteArray {
//            val state = input.copyOf() // 16-byte state
//            val expandedKey = keyExpansion(key)
//            addRoundKey(state, expandedKey, 0)
//            for (round in 1 until Nr) {
//                subBytes(state)
//                shiftRows(state)
//                mixColumns(state)
//                addRoundKey(state, expandedKey, round)
//            }
//            // Final round
//            subBytes(state)
//            shiftRows(state)
//            addRoundKey(state, expandedKey, Nr)
//            return state
//        }
//
//        // Decrypts a single 16-byte block.
//        fun decryptBlock(input: ByteArray, key: ByteArray): ByteArray {
//            val state = input.copyOf()
//            val expandedKey = keyExpansion(key)
//            addRoundKey(state, expandedKey, Nr)
//            for (round in Nr - 1 downTo 1) {
//                invShiftRows(state)
//                invSubBytes(state)
//                addRoundKey(state, expandedKey, round)
//                invMixColumns(state)
//            }
//            invShiftRows(state)
//            invSubBytes(state)
//            addRoundKey(state, expandedKey, 0)
//            return state
//        }
    }


}
